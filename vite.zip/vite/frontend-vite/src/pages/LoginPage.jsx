import React from 'react';
import Login from '../components/Auth/Login.jsx';

function LoginPage() {
  return <Login />;
}

export default LoginPage;