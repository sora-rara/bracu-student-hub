
import React from 'react';
import GPACalculator from '../components/Dashboard/GPA/GPACalculator.jsx';

function GPACalculatorPage() {
  return <GPACalculator />;
}

export default GPACalculatorPage;
