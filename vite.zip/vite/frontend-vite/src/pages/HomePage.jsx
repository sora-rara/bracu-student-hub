import React from 'react';
import Home from '../components/Home/Home.jsx';

function HomePage() {
  return <Home />;
}

export default HomePage;