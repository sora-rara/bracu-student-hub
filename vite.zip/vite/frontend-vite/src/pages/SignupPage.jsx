import React from 'react';
import Signup from '../components/Auth/Signup.jsx';

function SignupPage() {
  return <Signup />;
}

export default SignupPage;