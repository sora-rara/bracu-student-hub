import React from 'react';
import Dashboard from '../components/Dashboard/Dashboard.jsx';

function DashboardPage() {
  return <Dashboard />;
}

export default DashboardPage;